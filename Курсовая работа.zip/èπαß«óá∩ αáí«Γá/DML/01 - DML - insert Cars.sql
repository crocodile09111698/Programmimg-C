insert into [dbo].[�ars]
values (1, 2, 'Mazda', 'A326KM34', 'VGH4324NGSN42BF')
		,(2, 2, 'Audi', 'T767AA56', 'VTGY32453NXN5Y')
		,(3, 3, 'Lada', 'O887OO98', 'YHF35621NSGNSG');